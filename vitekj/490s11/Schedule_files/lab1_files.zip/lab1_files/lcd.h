#ifndef HAL_LCD_H
#define HAL_LCD_H

#define LCD_BACKLT_OUT      P8OUT
#define LCD_BACKLT_DIR      P8DIR
#define LCD_BACKLT_SEL      P8SEL
#define LCD_BACKLIGHT_PIN   BIT3
#define LCD_CS_RST_DIR      P9DIR
#define LCD_CS_RST_OUT      P9OUT  
#define LCD_CS_PIN          BIT6 
#define LCD_RESET_PIN       BIT7
#define LCD_SPI_SEL			P9SEL
#define LCD_SPI_DIR			P9DIR
#define LCD_MOSI_PIN		BIT1
#define	LCD_MISO_PIN		BIT2
#define LCD_CLK_PIN   		BIT3

#define LCD_ROW                 110
#define LCD_COL                 138
#define LCD_Size                3505
#define LCD_MEM_Size            110*17
#define LCD_Max_Column_Offset   0x10  
 
#define LCD_Last_Pixel          3505


#define LCD_MEM_Row             0x11
#define LCD_Row                 0x20

// Grayscale level definitions
#define PIXEL_OFF               0
#define PIXEL_LIGHT             1
#define PIXEL_DARK              2
#define PIXEL_ON                3

#define INVERT_TEXT             BIT0
#define OVERWRITE_TEXT          BIT2
#define GRAYSCALE_TEXT			BIT1

//extern int LCD_MEM[110*17];//This array stores a copy of all data on the LCD 
					  		//screen. If memory is an issue though, this array 
					  		//can be eliminated and the halLcdReadBlock()
					 		//command can be used instead whenever you are 
					 		//manipulating the currently displayed data.
#endif /* HAL_LCD_H */
