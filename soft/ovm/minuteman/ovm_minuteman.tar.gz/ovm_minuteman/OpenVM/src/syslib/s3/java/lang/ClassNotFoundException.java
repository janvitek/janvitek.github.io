package java.lang;


public class ClassNotFoundException extends Exception
{
  /**
   * Create an exception without a message.
   */
  public ClassNotFoundException()
    {
      super();
    }

  /**
   * Create an exception with a message.
   */
  public ClassNotFoundException(String s)
    {
      super(s);
    }
}
