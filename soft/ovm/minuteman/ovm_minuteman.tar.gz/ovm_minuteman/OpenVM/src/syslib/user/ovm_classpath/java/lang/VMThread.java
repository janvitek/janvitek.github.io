package java.lang;

/**
 * All standard java behavior is implemented in VMThreadBase.  The
 * class VMThread is free to override this behavior in other library
 * configurations.
 */ 
class VMThread extends VMThreadBase {
    VMThread(Thread t) { super(t); }
    // constructor for primordial VMThread
    VMThread(int priority, boolean daemon) { super(priority, daemon); }
}