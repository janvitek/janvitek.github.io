package javax.realtime;
import org.ovmj.java.Opaque;
class LibraryImports {

    static native Opaque getVMThread(Thread t);
    static native void threadSetInterrupted(Thread t, boolean set);
    static native void startThreadDelayed(Opaque vmThread, long startTime);
    static native int delayCurrentThreadAbsolute(long nanos);
    static native int delayCurrentThreadAbsoluteUninterruptible(long nanos);
    static native boolean setPriorityIfAllowed(Opaque vmThread, int newPrio);
    static native int getMinRTPriority();
    static native int getMaxRTPriority();
    static native long getCurrentTime();
    static native long getClockResolution();

    // signal monitoring related functions

    static native Opaque createSignalWatcher();
    static native void addSignalWatch(Opaque watcher, int sig);
    static native void removeSignalWatch(Opaque watcher, int sig);
    static native boolean canMonitorSignal(int sig);
    static native void waitForSignal(Opaque watcher, int[] counts);

    // interrupt monitoring related functions
    

    static native boolean waitForInterrupt(int interruptIndex );
    static native void interruptServed( int interruptIndex );
    static native boolean isMonitoredInterrupt( int interruptIndex );
    static native boolean stopMonitoringInterrupt( int interruptIndex );
    static native boolean startMonitoringInterrupt( int interruptIndex );

    // sizeof

    // We'd like to have the Opaque vmType reference but it's not accessible
    // so the ED will grab it directly
    static native long sizeOf(Class type);
    static native long sizeOfReferenceArray(int length);
    static native long sizeOfPrimitiveArray(int length, Class type);
    static native long sizeOfMonitor();

    // direct monitor access for scoped memory support
    static native void monitorEnter(Object o);
    static native void monitorExit(Object o);
    static native void monitorTransfer(Object o, Opaque newOwner);

    // absolute MonitorWait method
    static native boolean monitorAbsoluteTimedWait(Object o, long deadline);

    // Memory areas

    static native Opaque     getHeapArea();
    static native Opaque     getImmortalArea();
    static native Opaque     makeArea(MemoryArea mirror, int size);
    static native Opaque     makeExplicitArea(int size);
    static native Opaque     setCurrentArea(Opaque area);
    static native Opaque     getCurrentArea();
    static native Opaque     areaOf(Object ref);

    static native void       setParentArea(Opaque child, Opaque parent);
    static native void       resetParentArea(Opaque child);
    static native boolean    hasChildArea(Opaque area);
    static native boolean    hasMultipleChildren(Opaque area);
    static native int        getHierarchyDepth(Opaque area);
    
    static native void       resetArea(Opaque area);
    static native void       destroyArea(Opaque area);

    static native boolean    runFinalizers(Opaque area);
    static native MemoryArea getAreaMirror(Opaque area);
    static native int        memoryConsumed(Opaque area);
    static native int        memoryRemaining(Opaque area);
    static native int        getAreaSize(Opaque area);

    static native boolean    isProperDescendant(Opaque child, Opaque parent);
    static native boolean    isScope(Opaque area);
    
    static native boolean    reallySupportNHRTT();
    static native boolean    supportScopeAreaOf();

    // misc

    static native void      disableHeapChecksForTermination(Thread current);

    static native void      storeInOpaqueArray(Opaque[] arr, int index, Opaque val);

    static native void      copyArrayElements(Object from, int fromIndex,
                                              Object to, int toStartIndex,
                                              int howMany);
    
    // for debugging

    static native void      showAddress(Opaque a);
    static native int       toAddress(Object a);
   
    static native void      printString(String str);

    // priority inheritance testing
    static native int getInheritanceQueueSize(Thread thread);
    static native boolean checkInheritanceQueueHead(Thread thread, Thread t);
    static native boolean checkInheritanceQueueTail(Thread thread, Thread t);
    static native int getBasePriority(Thread thread);
    static native int getActivePriority(Thread thread);
    
    // RTGC
    static native void runGCThread();
    static native void setShouldPause(boolean shouldPause);
    static native boolean needsGCThread();
    static native int getGCTimerMutatorCounts();
    static native int getGCTimerCollectorCounts();
    static native int getGCThreadPriority();

}
