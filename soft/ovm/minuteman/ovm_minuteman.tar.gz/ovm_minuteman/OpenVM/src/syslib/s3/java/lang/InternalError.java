package java.lang;


public class InternalError extends Error
{
  /**
   * Create an exception without a message.
   */
  public InternalError()
    {
      super();
    }

  /**
   * Create an exception with a message.
   */
  public InternalError(String s)
    {
      super(s);
    }
}
