package java.lang;


public class InstantiationException extends Exception
{
  /**
   * Create an exception without a message.
   */
  public InstantiationException()
    {
      super();
    }

  /**
   * Create an exception with a message.
   */
  public InstantiationException(String s)
    {
      super(s);
    }
}
