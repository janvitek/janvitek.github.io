package java.lang;


public class ClassCastException extends RuntimeException
{
  /**
   * Create an exception without a message.
   */
  public ClassCastException()
    {
      super();
    }

  /**
   * Create an exception with a message.
   */
  public ClassCastException(String s)
    {
      super(s);
    }
}
