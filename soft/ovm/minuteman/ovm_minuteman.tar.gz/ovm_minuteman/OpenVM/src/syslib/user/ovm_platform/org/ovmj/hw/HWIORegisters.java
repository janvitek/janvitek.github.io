
package org.ovmj.hw;

public interface HWIORegisters {

};

