package org.ovmj.util;

/**
 * @see http://ovmj.org/doc/javadoc/s3/util/PragmaForwardCallingContext.html
 **/
public class PragmaForwardCallingContext extends PragmaException {
}
