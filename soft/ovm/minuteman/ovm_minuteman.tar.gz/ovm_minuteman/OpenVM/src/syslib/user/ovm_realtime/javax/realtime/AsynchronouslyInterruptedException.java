package javax.realtime;
/**
 * Skeleton placeholder to allow compilation - OVM does not yet support async
 * interruption.
 */
public class AsynchronouslyInterruptedException extends InterruptedException {
}
