
package org.ovmj.hw;

public final class DelayPort extends HardwareObject {

  public volatile int dummy; // x86 delay port, both read and write should always take 1 microsecond
  
}
