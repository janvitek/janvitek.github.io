package java.lang.reflect;


public class InvocationTargetException extends Exception
{
  /**
   * Create an exception without a message.
   */
  public InvocationTargetException()
    {
      super();
    }

  /**
   * Create an exception with a message.
   */
  public InvocationTargetException(String s)
    {
      super(s);
    }
}
