package java.io;

public class EOFException 
    extends IOException {
    public EOFException(String s) {
	super(s);
    }
    public EOFException() {
    }
}
