package org.ovmj.util;

public class PragmaNoInline extends PragmaException {
}
