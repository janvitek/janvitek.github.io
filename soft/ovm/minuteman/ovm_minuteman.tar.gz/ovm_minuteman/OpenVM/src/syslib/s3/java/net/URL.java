package java.net;

// FIXME: HACK for GC. CG/JV
public class URL {
}
