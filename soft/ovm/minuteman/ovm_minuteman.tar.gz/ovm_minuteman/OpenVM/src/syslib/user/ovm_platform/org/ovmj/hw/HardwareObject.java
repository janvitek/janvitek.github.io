
package org.ovmj.hw;

public abstract class HardwareObject {

  // package access only
  HardwareObject() {};
  
}