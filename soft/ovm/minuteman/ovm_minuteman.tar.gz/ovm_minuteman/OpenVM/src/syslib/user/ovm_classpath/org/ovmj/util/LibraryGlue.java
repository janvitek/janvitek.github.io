package org.ovmj.util;

class LibraryGlue {
    static native long RUsage_getSysTime();
    static native long RUsage_getUserTime();
}
