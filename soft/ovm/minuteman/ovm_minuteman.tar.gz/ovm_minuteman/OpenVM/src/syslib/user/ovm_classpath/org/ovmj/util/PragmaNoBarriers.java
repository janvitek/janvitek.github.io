// $Header: /p/sss/cvs/OpenVM/src/syslib/user/ovm_classpath/org/ovmj/util/PragmaNoBarriers.java,v 1.1 2004/02/21 03:20:22 pizlofj Exp $

package org.ovmj.util;

/**
 *
 * @author Filip Pizlo
 */
public class PragmaNoBarriers extends PragmaException {
}

