package java.nio;

final class LibraryGlue {



//     static void unmapImpl(MappedByteBufferImpl _) {
// 	LibraryImports.unmap(_.implPtr,
// 			     (int)_.implLen);
//     }
    static boolean isLoadedImpl(MappedByteBufferImpl _) {
	throw new Error("not implemented");
    }
    static void loadImpl(MappedByteBufferImpl _) {
	throw new Error("not implemented");
    }
    static void forceImpl(MappedByteBufferImpl _) {
	throw new Error("not implemented");
    }
    
    

}