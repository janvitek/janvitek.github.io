package java.io;


public class ObjectOutputStream {
}
