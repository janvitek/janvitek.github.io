package java.io;


public class ObjectInputStream {
}
