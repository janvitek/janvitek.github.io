package java.io;


public class Writer {
}
