package java.lang;


public class ThreadDeath extends Error
{
  /**
   * Create an exception without a message.
   */
  public ThreadDeath()
    {
      super();
    }

  /**
   * Create an exception with a message.
   */
  public ThreadDeath(String s)
    {
      super(s);
    }
}
