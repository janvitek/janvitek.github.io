package org.ovmj.java;

/**
 * Interface representing in user domain pointers to the executive domain.
 **/

public interface Opaque {
}
