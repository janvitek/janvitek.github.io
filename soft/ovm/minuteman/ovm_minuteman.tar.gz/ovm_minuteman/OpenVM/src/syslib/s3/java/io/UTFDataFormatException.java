package java.io;

public class UTFDataFormatException 
    extends IOException {
    public UTFDataFormatException(String s) {
	super(s);
    }
    public UTFDataFormatException() {
    }
}
