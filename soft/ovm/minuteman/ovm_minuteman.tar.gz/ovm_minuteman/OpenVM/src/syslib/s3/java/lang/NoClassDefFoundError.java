package java.lang;


public class NoClassDefFoundError extends LinkageError
{
  public NoClassDefFoundError() {
  }
    
  public NoClassDefFoundError(String s) {
      super(s);
    }
}
