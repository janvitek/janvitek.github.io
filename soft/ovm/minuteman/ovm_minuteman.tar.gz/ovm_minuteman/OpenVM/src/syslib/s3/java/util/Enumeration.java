package java.util;


public interface Enumeration {
}
