package java.lang;

public final class Short implements Comparable {
    public static final short MIN_VALUE = -0x8000;
    public static final short MAX_VALUE = 0x7FFF;
    // public static final java.lang.Class TYPE = null ;
    public static java.lang.String toString(short dummy) {
	throw new Error("not implemented");
    }
    public static short parseShort(String s) 
	throws java.lang.NumberFormatException {
	throw new Error("not implemented");
    }
    public static short parseShort(String s, int dummy) 
	throws NumberFormatException {
	throw new Error("not implemented");
    }
    public static Short valueOf(String dummy1, int dummy2) 
	throws NumberFormatException {
	throw new Error("not implemented");
    }
		
    public static Short valueOf(String dummy) throws NumberFormatException {
	throw new Error("not implemented");
    }
    public static Short decode(String dummy) throws NumberFormatException {
	throw new Error("not implemented");
    }
    public Short(short dummy) {
	throw new Error("not implemented");
    }
    public Short(String dummy) throws NumberFormatException {
	throw new Error("not implemented");
	
    }
    public byte byteValue() {
	throw new Error("not implemented");

    }
    public short shortValue() {
	throw new Error("not implemented");
    }
    public int intValue() {
	throw new Error("not implemented");
    }

    public long longValue() {
	throw new Error("not implemented");
    }
    public float floatValue() {
	throw new Error("not implemented");
    }
    public double doubleValue() {
	throw new Error("not implemented");
    }

    public String toString() {
	throw new Error("not implemented");
    }

    public int hashCode() {
	throw new Error("not implemented");
    }

    public boolean equals(Object dummy) {
	throw new Error("not implemented");

    }
    public int compareTo(Short dummy) {
	throw new Error("not implemented");
    }
    public int compareTo(Object dummy) {
	throw new Error("not implemented");
    }
}
