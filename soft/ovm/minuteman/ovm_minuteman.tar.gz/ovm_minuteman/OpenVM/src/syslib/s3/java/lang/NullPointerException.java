package java.lang;


public class NullPointerException extends RuntimeException
{
  /**
   * Create an exception without a message.
   */
  public NullPointerException()
    {
      super();
    }

  /**
   * Create an exception with a message.
   */
  public NullPointerException(String s)
    {
      super(s);
    }
}
