package org.ovmj.java;

public class UncheckedPriorityParameters extends javax.realtime.PriorityParameters {
    
    public UncheckedPriorityParameters(int priority) {
	super(priority);
    }
}

