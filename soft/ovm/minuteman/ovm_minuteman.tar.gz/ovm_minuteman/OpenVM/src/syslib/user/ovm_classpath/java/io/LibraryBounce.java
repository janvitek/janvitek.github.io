package java.io;

import gnu.java.nio.channels.FileChannelImpl;

public class LibraryBounce {

    /* bouncers */

    public static FileInputStream makeFIS(FileChannelImpl ch) {
	return new FileInputStream(ch);
    }

    public static FileOutputStream makeFOS(FileChannelImpl ch) {
	return new FileOutputStream(ch);
    }
}