package org.ovmj.hw;

public class PragmaNoHWIORegistersAccess extends RuntimeException {};
