package org.ovmj.util;

public class RUsage {
    static public native long getSysTime();
    static public native long getUserTime();
}
