// $Header: /p/sss/cvs/OpenVM/src/syslib/user/ovm_classpath/java/net/LibraryBounce.java,v 1.1 2004/04/05 17:50:14 pizlofj Exp $

package java.net;

/**
 *
 * @author Filip Pizlo
 */
public class LibraryBounce {
    public static SocketImpl sockGetImpl(ServerSocket serv) {
        return serv.getImpl();
    }
}

