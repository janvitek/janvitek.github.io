package org.ovmj.transact;

import org.ovmj.util.PragmaException;

/**
 * Marker exception used to define atomic methods.   
 * @author janvitek
 */
public  class Atomic extends  PragmaException {}
