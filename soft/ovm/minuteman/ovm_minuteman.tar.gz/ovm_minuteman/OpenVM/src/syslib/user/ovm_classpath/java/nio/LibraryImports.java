package java.nio;

//import gnu.classpath.RawData;

final class LibraryImports {


//     static native int unmap(RawData raw,
// 			    int size);

}