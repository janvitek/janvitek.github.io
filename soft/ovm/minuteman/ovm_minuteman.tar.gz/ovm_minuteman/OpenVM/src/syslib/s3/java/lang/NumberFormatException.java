package java.lang;


public class NumberFormatException extends IllegalArgumentException {
    /**
     * Create an exception without a message.
     */
    public NumberFormatException() {
	super();
    }
    
    /**
     * Create an exception with a message.
     */
    public NumberFormatException(String s) {
	super(s);
    }
}
