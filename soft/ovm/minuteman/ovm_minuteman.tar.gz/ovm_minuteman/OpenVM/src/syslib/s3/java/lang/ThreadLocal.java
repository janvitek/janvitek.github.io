package java.lang;

// FIXME: HACK for GC. CG/JV
public class ThreadLocal {
}
