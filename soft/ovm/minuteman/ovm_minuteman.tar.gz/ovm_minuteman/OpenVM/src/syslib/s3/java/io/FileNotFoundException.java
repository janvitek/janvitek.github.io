package java.io;

public class FileNotFoundException 
    extends IOException {
    public FileNotFoundException(String s) {
	super(s);
    }
    public FileNotFoundException() {
    }
}
