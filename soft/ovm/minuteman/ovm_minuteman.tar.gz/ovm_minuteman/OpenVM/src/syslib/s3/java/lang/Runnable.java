package java.lang;


public interface Runnable
{
    public void run();
}
