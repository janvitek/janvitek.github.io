package java.lang;

public interface Comparable {
    int compareTo(Object other);
}

